package com.example.hani.b10509021;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private TextView textview1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textview1=(TextView) this.findViewById(R.id.textView1);
        Bundle bundle =this.getIntent().getExtras();
        String msg = bundle.getString("data");
        textview1.setText("B10509021:"+msg);
    }
}